#!/usr/bin/python
#-*- coding: utf-8 -*-

from odoo import models, fields, api, _

class budget_cut(models.Model):
    _name = "vit.budget_cut"
    _inherit = "vit.budget_cut"
