#!/usr/bin/python
#-*- coding: utf-8 -*-

from odoo import models, fields, api, _

class budget_cut(models.Model):

    _name = "vit.budget_cut"
    name = fields.Char( required=True, string="Name",  help="")
    nomor_sk_direksi = fields.Char( string="Nomor sk direksi",  help="")
    state = fields.Selection(selection=[('draft','Draft'), ('open', 'Open'), ('done', 'Validated')],  string="State",  help="")


    budget_id = fields.Many2one(comodel_name="crossovered.budget",  string="Budget",  help="")
    line_ids = fields.One2many(comodel_name="vit.budget_cut_lines",  inverse_name="budget_cut_id",  string="Lines",  help="")
