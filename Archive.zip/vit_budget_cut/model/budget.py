#!/usr/bin/python
#-*- coding: utf-8 -*-

from odoo import models, fields, api, _

class budget(models.Model):

    _name = "crossovered.budget"

    _inherit = "crossovered.budget"


