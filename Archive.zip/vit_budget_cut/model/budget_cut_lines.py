#!/usr/bin/python
#-*- coding: utf-8 -*-

from odoo import models, fields, api, _

class budget_cut_lines(models.Model):

    _name = "vit.budget_cut_lines"
    budgetary_position_id = fields.Char( string="Budgetary position",  help="")
    current_amount = fields.Float( string="Current amount",  help="")
    new_amount = fields.Float( string="New amount",  help="")
    name = fields.Char( required=True, string="Name",  help="")


    budget_cut_id = fields.Many2one(comodel_name="vit.budget_cut",  string="Budget cut",  help="")
